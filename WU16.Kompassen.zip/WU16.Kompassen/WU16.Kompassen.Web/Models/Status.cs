﻿namespace WU16.Kompassen.Web.Models
{
    public enum Status
    {
        Inactive = 0,
        Active = 1
    }
}